# XD Chat — System Architecture

## Main Modules
1. Super Admin
2. Workspace Management
3. Admin Management
4. Visitor Management
5. Chat Widget
6. Admin Inbox
7. API Layer
8. Security Layer
9. Logs & Notifications

## High-Level Flow
```text
Website Visitor
      |
      v
XD Chat Widget
      |
      v
API Layer
      |
      v
Database
      |
      v
Workspace Admin Inbox
```

## Workspace Isolation
Every important table includes `workspace_id`.

Example:
```sql
SELECT * FROM conversations
WHERE workspace_id = :workspace_id;
```

## Embed Code Example
```html
<script>
  window.XDChatConfig = {
    workspaceKey: "MC001_PUBLIC_KEY",
    title: "Marwari Cab Support",
    whatsapp: "+917240495000"
  };
</script>
<script src="https://yourdomain.com/xd-chat/widget.js"></script>
```

## v1.0 Technology Stack
- Frontend: HTML, CSS, Vanilla JavaScript
- Backend: PHP 8+
- Database: MySQL
- Realtime v1: AJAX polling
- Realtime v2: WebSocket
