# XD Chat — UI Guidelines

## Brand
Product Name: XD Chat
Tagline: Live Chat Made Simple

## UI Style
- Clean
- Fast
- Mobile-first
- Simple admin dashboard
- Easy customer chat widget

## Suggested Colors
### Modern Blue Theme
- Primary: #2563EB
- Dark: #0F172A
- Success: #22C55E
- Danger: #EF4444
- Background: #F8FAFC

### Premium Theme
- Black
- Gold
- White

## Widget UI
1. Floating button bottom right.
2. Popup chat window.
3. Name and mobile form.
4. Message area.
5. WhatsApp fallback.
6. Minimize/close option.

## Admin UI
1. Sidebar navigation.
2. Conversation list.
3. Chat window.
4. Visitor details panel.
5. Status change buttons.
