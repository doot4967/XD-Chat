# XD Chat — Release Notes

## v1.0.0 — Genesis
Planned first release.

### Features
- Super admin panel
- Workspace management
- Admin management
- Chat widget
- Visitor form
- Admin inbox
- Message history
- Workspace isolation
- Basic notifications

### Not Included in v1.0
- AI chatbot
- WhatsApp Business API
- Mobile app
- WebSocket realtime
- Advanced analytics
