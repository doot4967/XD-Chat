# XD Chat — Project Vision

## Product Name
**XD Chat**

## Tagline
**Live Chat Made Simple**

## Version
v1.0.0 — Genesis

## Vision
Build a professional, self-hosted, multi-workspace live chat platform that can be embedded into any website with a single script.

## Core Goals
1. One script installation for any website.
2. Multi-workspace support.
3. Multi-admin support.
4. No customer chat mixing between businesses.
5. Clean, reusable, original code.
6. Self-hosted v1.0 with zero required third-party API.
7. Future-ready for SaaS, AI, WhatsApp and mobile apps.

## Example Use Cases
- Marwari Cab live support.
- The Devil House live support.
- Restaurant booking enquiries.
- Travel/cab lead collection.
- Customer support inbox.

## Golden Rule
Each workspace has isolated data. Marwari Cab chats must never appear inside The Devil House admin panel.
