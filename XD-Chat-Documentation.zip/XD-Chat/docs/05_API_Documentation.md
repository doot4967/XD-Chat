# XD Chat — API Documentation

## API Rules
1. Every API response must return JSON.
2. Every request must validate workspace key.
3. Every chat request must be linked with workspace_id.
4. Never expose password hash.
5. Never trust frontend data directly.

## Planned API Endpoints

### Start Chat
`POST /api/start-chat.php`

Purpose:
Create visitor and conversation.

### Send Message
`POST /api/send-message.php`

Purpose:
Save customer/admin message.

### Get Messages
`GET /api/get-messages.php`

Purpose:
Fetch messages for a conversation.

### Close Conversation
`POST /api/close-conversation.php`

Purpose:
Close chat session.

### Admin Login
`POST /api/admin-login.php`

Purpose:
Authenticate workspace admin.

## Standard API Response
```json
{
  "success": true,
  "message": "Request completed successfully",
  "data": {}
}
```
