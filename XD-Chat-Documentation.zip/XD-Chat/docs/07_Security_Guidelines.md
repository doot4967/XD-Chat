# XD Chat — Security Guidelines

## Required Security
1. Password hashing.
2. SQL injection protection using prepared statements.
3. XSS protection.
4. CSRF protection for admin actions.
5. Workspace-based data filtering.
6. Session validation.
7. Rate limiting for chat form.
8. Secure admin login.
9. Activity logs for important actions.

## Workspace Safety
Every admin must have a workspace_id.
Every visitor must have a workspace_id.
Every conversation must have a workspace_id.
Every message must have a workspace_id.

## Query Rule
Never write admin data queries without workspace filter.

Correct:
```sql
SELECT * FROM conversations
WHERE workspace_id = :workspace_id;
```

Wrong:
```sql
SELECT * FROM conversations;
```
