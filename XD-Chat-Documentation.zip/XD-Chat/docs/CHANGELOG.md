# Changelog

## 04 July 2026
- Project name finalized: XD Chat.
- Tagline finalized: Live Chat Made Simple.
- Workspace naming selected instead of tenant.
- Documentation structure created.
- Initial database design drafted.
