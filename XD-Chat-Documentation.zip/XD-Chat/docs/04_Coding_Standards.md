# XD Chat — Coding Standards

## Code Rules
1. No duplicate code.
2. No unnecessary copy-paste.
3. Reusable components only.
4. Every function must have comments.
5. Every file must have a header block.
6. Related CSS must stay grouped together.
7. Naming must be simple and readable.
8. Hardcoded values should be avoided.

## File Header Example
```php
/*
===========================================
Project : XD Chat
Version : 1.0.0
Module  : Authentication
File    : login.php
Author  : XD Chat Team
Created : 04-07-2026
===========================================
*/
```

## Function Comment Example
```php
/**
 * ----------------------------------------------------
 * Function : loginAdmin()
 * Purpose  : Authenticate admin login
 * ----------------------------------------------------
 */
```

## CSS Grouping Order
1. Variables
2. Reset
3. Typography
4. Layout
5. Buttons
6. Forms
7. Cards
8. Header
9. Sidebar
10. Footer
11. Utilities
12. Responsive
