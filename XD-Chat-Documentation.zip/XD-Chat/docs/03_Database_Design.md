# XD Chat — Database Design

## ER Diagram
```text
SUPER_ADMIN
     |
     v
WORKSPACES
     |
     |---- ADMINS
     |---- VISITORS
     |---- WORKSPACE_SETTINGS
     |
     v
CONVERSATIONS
     |
     v
MESSAGES
```

## 01. workspaces
Stores each business/client website.

Columns:
- workspace_id
- workspace_name
- domain
- widget_key
- status
- created_at
- updated_at

## 02. admins
Stores workspace admin users.

Columns:
- admin_id
- workspace_id
- name
- email
- mobile
- password_hash
- role
- status
- last_login
- created_at
- updated_at

## 03. visitors
Stores customer/visitor details.

Columns:
- visitor_id
- workspace_id
- name
- mobile
- email
- ip_address
- device
- browser
- city
- country
- created_at

## 04. conversations
Stores chat sessions.

Columns:
- conversation_id
- workspace_id
- visitor_id
- assigned_admin_id
- status
- started_at
- closed_at
- updated_at

## 05. messages
Stores chat messages.

Columns:
- message_id
- workspace_id
- conversation_id
- sender_type
- sender_id
- message
- message_type
- is_read
- created_at

## Important Security Rule
All queries must filter by `workspace_id` wherever workspace data is involved.
